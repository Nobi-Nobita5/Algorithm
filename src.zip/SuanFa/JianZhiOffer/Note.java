package SuanFa.JianZhiOffer;

public class Note {
    /*
    Integer.parseInt(String s);    操作字符串转为整数
     */
}
