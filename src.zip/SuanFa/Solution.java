package SuanFa;

import MianShi.Single.Singleton2;
import SuanFa.JianZhiOffer.ListNode;
import SuanFa.TreeNode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Solution {
    public static void main(String[] args) throws IOException {
        String s = "from user";
        String[] split = s.split("\\s+");
        System.out.println(Arrays.toString(split));
    }
}
