package Java.SE;

public class Hero {

}
